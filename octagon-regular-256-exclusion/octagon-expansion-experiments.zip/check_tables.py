"""Test deductions against the original repository's committed tables."""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
import ast
import csv
import json
import re
import sys

import sympy as sp

root = Path(sys.argv[1])


def triple_vector():
    counts = Counter({(1,1,1):1})
    for r in (1,2,3):
        for first_line, first_point in product(range(5), range(2)):
            d = tuple(r+1 if j != first_line else r-1+first_point for j in range(3))
            counts[d] += 8**(r-1)
    for d in product([3,4],repeat=3):
        counts[d] += 128
    return counts


predicted = triple_vector()
records = 0
with (root/'triple/out_orbits/triple_orbit_vectors.csv').open() as source:
    for row in csv.DictReader(source):
        if ast.literal_eval(row['type']) == (2,2,2):
            actual = Counter({tuple(map(int,k)):int(v) for k,v in re.findall(r'\[(\d{3})\]=(\d+)', row['vector'])})
            assert actual == predicted
            records += 1
assert records == 3 and sum(predicted.values()) == 1755
print('All three (2,2,2) orbit vectors agree. [333] =', predicted[3,3,3])

j = json.loads((root/'flags/out/flag_scheme.json').read_text())
p = j['p']
opp = [i for i,w in enumerate(j['weyl']) if w == 'w0']
assert opp == [16,17]
mult = sp.Matrix(18,18,lambda i,k:sum(p[i][k][o] for o in opp))
spectrum = sorted(mult.eigenvals())
bound = Fraction(8775*(-min(spectrum)),max(spectrum)-min(spectrum))
assert bound == 135
weights = j['suborbits']
small = [i for i,w in enumerate(weights) if w <= bound]
solutions = []
for take in product([False,True],repeat=len(small)):
    cells = [i for i,chosen in zip(small,take) if chosen]
    if sum(weights[i] for i in cells) == bound and all(
        p[o][j['transpose'][a]][b] == 0 for o in opp for a in cells for b in cells):
        solutions.append(cells)
assert len(solutions) == 2
print('Chamber spectrum (distinct values)', spectrum, 'ratio bound',bound,'anchored stabilizer solutions',solutions)

source = root/'search/cayley/out_normal/tables_625.txt'
for row in source.read_text().splitlines():
    if row.startswith('G '):
        _,_,identifier,data = row.split(' ',3)
        pattern = r'(\[.*?\]) (\[.*?\]) (\[.*\])'
        _,orbit_sizes,characters = map(ast.literal_eval,re.fullmatch(pattern,data).groups())
        abelianization_order = sum(n for n,ch in zip(orbit_sizes,characters) if ch[0]==n)
        print('SmallGroup(625,%s) abelianization size'%identifier,abelianization_order)
