"""Rebuild the anchored graph and classify the large maximal cliques."""
from collections import Counter
from pathlib import Path
import argparse
import re
import sys
import urllib.request

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import shortest_path

ROOT = Path(__file__).resolve().parent
SOURCE = 'https://brauer.maths.qmul.ac.uk/Atlas/exc/TF42/gap/TF42d2G1-p1755B0.g{}'


def atlas_generators():
    for i in (1, 2):
        text = urllib.request.urlopen(SOURCE.format(i), timeout=60).read().decode()
        perm = np.arange(1755)
        for cycle in re.findall(r'\(([\d,\s]+)\)', text):
            points = np.array([int(x)-1 for x in re.sub(r'\s', '', cycle).split(',')])
            perm[points] = np.roll(points, -1)
        yield perm


def action_orbit(seed, generators):
    """Transport either a singleton or an unordered tuple under the two permutations."""
    ordered = [seed]
    seen = {seed}
    for item in ordered:
        for gen in generators:
            image = tuple(sorted(gen[list(item)]))
            if image not in seen:
                seen.add(image)
                ordered.append(image)
    return ordered


def distances(generators):
    assert len(action_orbit((0,), generators)) == 1755
    edges = np.array(action_orbit((0, 72), generators))
    assert len(edges) == 8775
    row, col = edges.T
    graph = csr_matrix((np.ones(len(row)), (row, col)), shape=(1755, 1755))
    dist = shortest_path(graph + graph.T, directed=False, unweighted=True).astype(int)
    assert tuple(np.bincount(dist[0])) == (1, 10, 80, 640, 1024)
    return dist


def line_orbits(line, families, generators, signatures):
    # Schreier permutations obtained by transporting a line along the two ATLAS generators.
    transversals = {line: np.arange(1755)}
    lines = [line]
    for current in lines:
        for gen in generators:
            target = tuple(sorted(gen[list(current)]))
            if target not in transversals:
                transversals[target] = gen[transversals[current]]
                lines.append(target)
    assert len(lines) == 2925
    inverse = {line: np.argsort(x) for line, x in transversals.items()}
    index = {x: i for i, x in enumerate(families)}
    parent = list(range(len(families)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    components = len(families)
    for current in lines:
        for gen in generators:
            target = tuple(sorted(gen[list(current)]))
            stabilizer_element = inverse[target][gen[transversals[current]]]
            if np.array_equal(stabilizer_element, np.arange(1755)):
                continue
            for i, points in enumerate(families):
                other = tuple(sorted(stabilizer_element[list(points)]))
                a, b = find(i), find(index[other])
                if a != b:
                    parent[a] = b
                    components -= 1
            if components == len(set(signatures)):
                return sorted(Counter(find(i) for i in range(len(families))).values())
    return sorted(Counter(find(i) for i in range(len(families))).values())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--atlas', action='store_true', help='compare bundled permutations to ATLAS')
    parser.add_argument('--graph-only', action='store_true')
    args = parser.parse_args()
    gens = np.load(ROOT/'generators.npy')
    if args.atlas:
        assert np.array_equal(gens, list(atlas_generators()))
    dist = distances(gens)
    cand = np.flatnonzero((dist[0] > 0) & (dist[0] < 4))
    m = dist[np.ix_(cand, cand)]
    expected = ''.join(''.join(map(str, row.astype(int)))+'\n' for row in ((m > 0) & (m < 4)))
    assert expected == (ROOT/'edges.txt').read_text()
    print('Transitive on 1755 points. Anchored graph agrees with bundled input.')
    if args.graph_only:
        return
    line = (0, 72, 1018)
    assert dist[np.ix_(line, line)].sum() == 6
    lines = np.array(action_orbit(line, gens))
    assert len(lines) == 2925
    canonical = set()
    for triple in lines:
        points = tuple(np.flatnonzero(dist[triple].min(axis=0) <= 1))
        assert len(points) == 27
        if 0 in points:
            canonical.add(points)
    assert len(canonical) == 45
    groups = Counter()
    on_line = []
    signatures = []
    large = set()
    for row in (ROOT/'maximal-cliques.txt').read_text().splitlines():
        points = tuple(sorted([0, *cand[list(map(int, row.split()))]]))
        assert points not in large
        large.add(points)
        d = dist[np.ix_(points, points)]
        assert d.max() == 3
        if len(points) == 27:
            assert points in canonical
            continue
        assert len(points) == 15
        degrees = (d == 1).sum(axis=0)
        assert sorted(degrees) == [0]*12 + [2]*3
        centre = tuple(np.array(points)[degrees == 2])
        assert dist[np.ix_(centre, centre)].sum() == 6
        outer = np.array(points)[degrees == 0]
        near = dist[np.ix_(centre, outer)]
        assert (near.min(axis=0) == 2).all()
        profile = tuple(sorted((near == 2).sum(axis=1)))
        groups[profile] += 1
        if centre == line:
            on_line.append(points)
            signatures.append(profile)
    assert canonical <= large
    assert groups == {(0,4,8):9600, (4,4,4):3200}
    assert len(on_line) == 512
    sizes = line_orbits(line, on_line, gens, signatures)
    assert sizes == [128,384]
    print('Anchored 15-point sets by projection counts', dict(groups))
    print('Stabilizer orbit sizes around a fixed central line', sizes)
    print('Global sizes', [2925*n for n in sizes])


if __name__ == '__main__':
    main()
