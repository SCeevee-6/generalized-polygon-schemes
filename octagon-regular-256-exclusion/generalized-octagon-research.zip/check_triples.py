"""Check the projection recurrence against the repository's seven adjacent-pair vectors."""
import ast
from collections import Counter
import csv
from pathlib import Path
import re
import sys

repo = Path(sys.argv[1])
with (repo/'data/intersection_numbers_independent_verification.csv').open() as handle:
    p = {(int(z['i']), int(z['j']), int(z['k'])):int(z['p^k_ij']) for z in csv.DictReader(handle)}
tested = 0
with (repo/'triple/out_orbits/triple_orbit_vectors.csv').open() as handle:
    for row in csv.DictReader(handle):
        a, b, c = ast.literal_eval(row['type'])
        if a != 1:
            continue
        distances = [b, c, b-1 if b == c else max(b,c)]
        result = Counter()
        for j in range(5):
            previous = [0]*3
            for h in range(5):
                current = [p[h,j,d] - sum(previous) + previous[i] for i,d in enumerate(distances)]
                assert min(current) >= 0
                for i, count in enumerate(current):
                    if count:
                        result[h+(i!=0), h+(i!=1), j] += count
                previous = current
        observed = Counter({tuple(map(int, key)):int(val) for key,val in re.findall(r'\[(\d{3})\]=(\d+)', row['vector'])})
        assert result == observed and sum(result.values()) == 1755
        tested += 1
        print(row['type'], 'agrees')
assert tested == 7
