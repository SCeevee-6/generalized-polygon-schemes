# Non-opposite sets in generalized octagons

Based on https://github.com/SCeevee-6/generalized-polygon-schemes/tree/27fdb68cea90d375044f7316d58ef6f56895526a .

- Read proof.md for a hand proof extending the maximum-set result to every finite thick order.
- For the known Ree–Tits octagon O(2), every pairwise non-opposite set of size at least 16 is contained in a line neighbourhood. Two orbits of size-15 exceptions attain the sharp bound. The universal analogue of this stability result is open in this investigation.
- To pursue uniqueness, the published reduction to existence of an order-(2,1) suboctagon is due to De Bruyn (Discrete Mathematics 2015, doi:10.1016/j.disc.2015.04.022). His text gives both the 24,960 known suboctagons and a four-point closure seed. A positive lower bound on the number of successful seeds in an arbitrary GO(2,4) would suffice. The compatibility of partial seed closures is the unproved step.

## Reproduce the finite computation

Use GNU g++ with libstdc++ (the dynamic set-bit iterator is a GNU extension), Python 3, NumPy and SciPy. Inside the extracted directory run

    python audit.py --graph-only
    g++ -std=c++17 -O3 verify.cpp -o verify
    ./verify
    python audit.py

Optionally pass --atlas to audit.py to compare the two cached permutations with the ATLAS source over the network. All other steps run offline. The file generators.npy contains the zero-based images of the standard generators c,d of TF42d2G1-p1755B0. Transporting the edge {0,72} produces the collinearity graph. The script checks transitivity, shell sizes and the complete adjacency input to the clique search.

The 730-by-730 file edges.txt is the induced non-opposition graph on the other points compatible with point 0. verify.cpp enumerates every inclusion-maximal clique of size at least 14 in this graph, which corresponds to size at least 15 including the anchor. A maximal clique here is also maximal in the whole graph, because any extension has to be compatible with point 0. The search uses ordinary Bron–Kerbosch pivoting and a proper-colouring upper bound. It receives no list of lines or exclusions. It produces maximal-cliques.txt (vertex indices into the increasing list of the 730 candidates). Expected counts are 12,800 at 15 and 45 at 27, and zero at every other size above 14. An initial, separate, maximum-clique search also found a largest exception of 15.

audit.py verifies that all 45 maximum cliques are precisely the line neighbourhoods through the anchor. Each 15-point maximal set has exactly three collinear pairs, making one full line, and all other twelve members are at distance two from this line. Distribute those twelve by their unique closest point on the line. The occupancies are (4,4,4) or (0,4,8), up to permutation. The file checks that each profile forms one orbit under the ATLAS group: its stabilizer of a fixed central line is transitive on the 128, respectively 384, sets with that profile and centre. Globally there are 374,400 and 1,123,200 exceptions. These computations concern the known Ree–Tits example.

## Triple vectors with a collinear pair

Let u,v be different points on a line L and fix a point w. For each shell d(x,w)=j, let B_h(p) count the x with closest point p on L and d(x,L)=h. Put T_h=Σ_{p∈L}B_h(p) and start with B₋₁=0. If p is a fixed point of L, the intersection number pᵈ⁽ᵖ˒ʷ⁾_{h,j} counts x at distances h from p and j from w. By the unique nearest point axiom,

    B_h(p) = p^{d(p,w)}_{h,j} − T_{h−1} + B_{h−1}(p).

Distances from w to L have a single minimum, with all other values one larger. Their multiset and the values at u,v are determined by the two distances d(u,w),d(v,w). Counts for x projecting to u, v or another point contribute to the pairs of distances (h,h+1), (h+1,h), (h+1,h+1), respectively. Hence the whole triple vector with a collinear pair is forced by the intersection numbers and the distances of the base triple, in any regular near polygon with this line projection property. This is also a consequence of the known theory of equitable distance partitions around an edge in 1-homogeneous graphs. See the references surrounding doi:10.5802/alco.454. Use it as a reduction in the search for new rigidity.

The script check_triples.py takes a path to the pinned repository checkout. It checks every component against all seven recorded collinear-pair types in O(2). The four (1,2,2), (1,3,3), (1,3,4), (1,4,4) have positive residual degrees of freedom in the repository's family/triple-tree model. These are separate from the 60 relations for six larger types.
