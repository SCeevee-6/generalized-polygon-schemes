#include <algorithm>
#include <array>
#include <bitset>
#include <fstream>
#include <iostream>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

// Enumerate maximal cliques through the anchor by the Bron-Kerbosch algorithm.
// The anchor is implicit. Its 730 neighbours form the input graph.
constexpr int vertices = 730;
using Set = std::bitset<vertices>;
std::array<Set, vertices> adjacent;
std::vector<int> chosen;
std::map<int, long> counts;
std::ofstream solutions("maximal-cliques.txt");

int colour_bound(Set uncoloured, int needed) {
    int colours = 0;
    while (uncoloured.any() && colours < needed) {
        ++colours;
        Set available = uncoloured;
        while (available.any()) {
            int v = available._Find_first();
            uncoloured.reset(v);
            available.reset(v);
            available &= ~adjacent[v];
        }
    }
    return colours;
}

void enumerate(Set possible, Set excluded) {
    if (possible.none()) {
        if (excluded.none() && chosen.size() >= 14) {
            ++counts[1 + chosen.size()];
            for (int v : chosen) solutions << v << ' ';
            solutions << '\n';
        }
        return;
    }
    int needed = 14 - static_cast<int>(chosen.size());
    if (static_cast<int>(possible.count()) < needed || colour_bound(possible, needed) < needed) return;
    Set pivot_pool = possible | excluded;
    int pivot = pivot_pool._Find_first();
    int best = -1;
    for (int v = pivot; v < vertices; v = pivot_pool._Find_next(v)) {
        int score = (adjacent[v] & possible).count();
        if (score > best) {
            best = score;
            pivot = v;
        }
    }
    Set branches = possible & ~adjacent[pivot];
    for (int v = branches._Find_first(); v < vertices; v = branches._Find_next(v)) {
        chosen.push_back(v);
        enumerate(possible & adjacent[v], excluded & adjacent[v]);
        chosen.pop_back();
        possible.reset(v);
        excluded.set(v);
    }
}

int main() {
    std::ifstream input("edges.txt");
    if (!input || !solutions) throw std::runtime_error("Input or output could not be opened");
    for (int i = 0; i < vertices; ++i) {
        std::string row;
        if (!(input >> row) || row.size() != vertices) throw std::runtime_error("Bad row length");
        for (int j = 0; j < vertices; ++j) adjacent[i][j] = row[j] == '1';
    }
    Set all;
    all.set();
    enumerate(all, {});
    for (auto [size, count] : counts) std::cout << size << " points: " << count << '\n';
    return counts == std::map<int,long>{{15,12800},{27,45}} ? 0 : 1;
}
