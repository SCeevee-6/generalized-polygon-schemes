"""Replication for expansion experiments. See README.md for the two arguments."""
import argparse
from collections import Counter
from itertools import combinations
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components, shortest_path


def traces(dist):
    outside = np.flatnonzero(dist[0] == 4)
    inner_pairs = [(u,v) for u,v in combinations(np.flatnonzero(dist[0] == 1), 2) if dist[u,v] == 1]
    labels = np.stack([dist[u,outside] == 3 for u,_ in inner_pairs]).T @ (2**np.arange(5))
    adjacency = dist[np.ix_(outside,outside)] == 1
    ncomp, components = connected_components(adjacency)
    assert ncomp == 2
    for component in range(ncomp):
        take = components == component
        words = labels[take]
        assert sorted(Counter(words).values()) == [32]*16
        edges = adjacency[np.ix_(take,take)]
        flips = [31 ^ (1 << i) for i in range(5)]
        steps = []
        for u in range(len(words)):
            by_flip = {int(words[u]^words[v]):v for v in np.flatnonzero(edges[u])}
            assert set(by_flip) == set(flips) and edges[u].sum() == 5
            steps.append([by_flip[f] for f in flips])
        steps = np.array(steps)
        # A lift preserving the projection is fixed by the image of one vertex.
        order = [0]
        parent = {0:None}
        for u in order:
            for i,v in enumerate(steps[u]):
                if v not in parent:
                    parent[v] = (u,i)
                    order.append(v)
        assert len(order) == 512
        identity = np.arange(512)
        deck = []
        for image in np.flatnonzero(words == words[0]):
            perm = np.zeros(512, dtype=int)
            perm[0] = image
            for v in order[1:]:
                u,i = parent[v]
                perm[v] = steps[perm[u],i]
            if np.array_equal(perm[steps], steps[perm]) and len(set(perm)) == 512:
                assert np.array_equal(perm[perm],identity)
                deck.append(perm)
        assert len(deck) == 32
        print('component', component, 'vertices', len(words), 'deck order', len(deck), 'exponent 2')


def thin_blocks(dist, gens, orbit):
    root = 0
    opposite = np.flatnonzero(dist[root]==4)[0]
    seed = {root, opposite, *np.flatnonzero((dist[opposite]==1)&(dist[root]==3))[:2]}
    while True:
        enlarged = set(seed)
        for a in seed:
            for b in seed:
                d = dist[a,b]
                if d in (1,2,3):
                    enlarged.update(np.flatnonzero((dist[a]==1)&(dist[b]==max(1,d-1))))
        if enlarged == seed:
            break
        seed = enlarged
    base = tuple(sorted(seed))
    assert len(base) == 45
    blocks = orbit(base, gens)
    assert len(blocks) == 24960
    members = np.asarray(blocks)
    intersection_size = np.isin(members,base).sum(axis=1)
    histogram = dict(sorted(Counter(map(int,intersection_size)).items()))
    assert histogram == {0:12584,1:6480,2:1080,3:3120,5:1170,9:480,13:45,45:1}
    print('thin suboctagon overlap histogram', histogram)
    neighbors = np.flatnonzero(intersection_size == 13)
    balls = {tuple(sorted(x for x in base if dist[v,x] <= 2)) for v in base}
    overlaps = {tuple(sorted(seed.intersection(blocks[i]))) for i in neighbors}
    assert len(balls) == 45 and overlaps == balls
    index = {x:i for i,x in enumerate(blocks)}
    actions = [np.array([index[tuple(sorted(g[list(x)]))] for x in blocks]) for g in gens]
    adj = np.full((len(blocks),45), -1, dtype=int)
    adj[0] = neighbors
    queue = [0]
    for i in queue:
        for g in actions:
            j = g[i]
            if adj[j,0] < 0:
                adj[j] = g[adj[i]]
                queue.append(j)
    graph = csr_matrix((np.ones(adj.size), (np.repeat(np.arange(len(blocks)),45),adj.ravel())),
                       shape=(len(blocks),len(blocks)))
    assert (graph != graph.T).nnz == 0
    _, component = connected_components(graph)
    assert list(np.bincount(component)) == [12480,12480]
    # The derived subgroup generators are c and h^-1 (cd)^4 h in the repository's right-action convention.
    c,d = actions
    def word(w):
        perm = np.arange(len(blocks))
        for letter in w:
            perm = {'c':c, 'd':d}[letter][perm]
        return perm
    h = word('dcddcdcddd')
    derived = [c, h[word('cdcdcdcd')[np.argsort(h)]]]
    half = orbit((0,), derived)
    assert {v for v, in half} == set(np.flatnonzero(component == component[0]))
    distances = shortest_path(graph, indices=0, unweighted=True)
    print('component shells', np.bincount(distances[np.isfinite(distances)].astype(int)))


def smith_counts(matrix):
    # Work over Z/2^16. Unit pivots split off free summands. When every remaining
    # entry is even, divide the remainder by 2 and record the next valuation.
    data = matrix.astype(np.uint16)
    size = len(data)
    first = 0
    counts = []
    for _ in range(16):
        start = first
        last = size
        while first < last:
            rows = np.flatnonzero(data[first:,first] & 1)
            if len(rows) == 0:
                last -= 1
                data[first:,[first,last]] = data[first:,[last,first]]
                continue
            pivot = first + rows[0]
            data[[first,pivot],first:] = data[[pivot,first],first:]
            inv = np.uint16(pow(int(data[first,first]), -1, 65536))
            for i in range(first+1,size,96):
                block = data[i:i+96,first:]
                block -= (block[:,0:1]*inv)*data[first,first:]
            first += 1
        counts.append(first-start)
        if first == size:
            return counts
        remaining = data[first:,first:]
        assert not (remaining & 1).any()
        remaining >>= 1
    raise ValueError('Precision exhausted before matrix was exhausted')


def smith(dist, gens, orbit):
    lines = np.array(orbit((0,72,1018),gens))
    incidence = csr_matrix((np.ones(lines.size), (np.repeat(np.arange(len(lines)),3),lines.ravel())),
                           shape=(2925,1755))
    dual = incidence @ incidence.T
    dual.setdiag(0)
    dual.eliminate_zeros()
    dual_dist = shortest_path(dual, directed=False, unweighted=True)
    for label, distances, expected, valuation in (
        ('points',dist,[26,272,52,324,406,272,78,246,52,26,1],7182),
        ('lines',dual_dist,[246,350,78,872,52,82,894,26,78,246,0,1],12135),
    ):
        counts = smith_counts(distances==4)
        assert counts == expected and sum(i*c for i,c in enumerate(counts)) == valuation
        print(label, 'multiplicities of 2^i', counts, 'determinant valuation', valuation)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original_bundle', type=Path)
    parser.add_argument('experiment', choices=['traces','blocks','smith','all'])
    args = parser.parse_args()
    sys.path.insert(0, str(args.original_bundle.resolve()))
    from audit import action_orbit, distances
    gens = np.load(args.original_bundle/'generators.npy')
    dist = distances(gens)
    if args.experiment in ('all','traces'):
        traces(dist)
    if args.experiment in ('all','blocks'):
        thin_blocks(dist,gens,action_orbit)
    if args.experiment in ('all','smith'):
        smith(dist,gens,action_orbit)


if __name__ == '__main__':
    main()
