# Six experiments for the generalized-polygon project

These use the original repository at commit 27fdb68 and the previously supplied generalized-octagon-research.zip. The computations concern the known Ree–Tits model unless a separate argument below states the axioms used. The evidence does not establish bibliographic priority.

## Running the checks

Extract the earlier ZIP to a directory containing audit.py and generators.npy. With Python 3, NumPy and SciPy, run

    python check.py /path/to/earlier/bundle all

The final argument can also be traces, blocks, or smith. The program needs no network access. With a checkout of the original repository and SymPy, run

    python check_tables.py /path/to/generalized-polygon-schemes

The first script independently rebuilds the geometry from the earlier ZIP's generators. For the block graph it transports one neighbour list under the group and checks that the resulting graph is symmetric. The second script reads the original orbit vectors, chamber multiplication table and GAP output. Distances in the discussions below are point-graph distances in the geometry named.

## 1. Classify the coverings of the opposite layer

In any GO(2,4), fix a point x. Number the five lines through x and label the other two points on each line 0,1. Each of the 1,024 points y opposite x has a word of length five: take on each line the unique point at distance 3 from y. Call it the trace word.

For two adjacent outer points b,c, the third point z of their common line is at distance 3 from x. The unique geodesic to z starts through a point p on one of the five lines. Both words select p. If another coordinate agrees, its selected point p' is at distance 3 from b and c, so it must be at distance 2 from the third point z by projection onto their line. This supplies a second geodesic from x to z, impossible. Thus exactly four bits flip. Each b has five outer neighbours. Its five geodesics from x have distinct first lines and distinct last lines (uniqueness for interior subpaths and unique projection onto each terminal line). Thus its five outer edges realize each of the five possible four-bit flips once.

This makes each connected component a graph cover of one parity class of the binary five-cube with adjacency at Hamming distance four. Each parity class is the 16-vertex folded five-cube, or Clebsch graph. Label choices can swap the names of the two parities. In any such finite octagon each word of one parity occurs a times, and each word of the other parity b times, with a+b=64. This follows by bijection between neighbouring fibres of a covering. For j≤4, each prescribed j-bit pattern therefore occurs 1024/2^j times. For j=5 the counts depend on a,b.

In the Ree–Tits model, all words occupy one parity. The outer graph has two 512-point components. Each is a regular 32-sheeted cover with deck group elementary abelian of order 32. The script tries all images of a chosen vertex in its fibre; a spanning tree forces the rest of the permutation. It checks each resulting bijection against all edges. All 32 permutations square to the identity.

**Experiment.** A connected elementary abelian 32-cover of this base is specified by a codimension-five subspace of its binary cycle space, of dimension 40−16+1=25, up to base-graph symmetries for unlabelled covers. Derive necessary restrictions on this subspace from girth and from how the depth-three layer attaches. Encode the known cover first. Test which constraints are forced with no regularity or automorphism assumption on the ambient octagon. Regularity of the known cover alone does not justify requiring regular covers in general.

**Triple consequence.** Every triple of pairwise distance-two points has a common neighbour x and belongs to three distinct lines through x. The three length-four incidence geodesics between the triple points cannot form a circuit of length ≤12; their tree is a tripod with three length-two legs. On the outer layer, all eight possible distance profiles in {3,4}³ occur 128 times each, by three-coordinate uniformity. In shells of radii r=1,2,3 about x, each fixed first point along a geodesic accounts for 8^(r−1) vertices; it determines all three distances. This gives the complete triple vector in every GO(2,4). For example [333]=128+32=160. The checker verifies every coordinate for the three recorded orbits. Try simultaneous traces at two roots on the still-unexplained types.

Cohen, O'Brien and Shpectorov already colour the five outer edges at each vertex and describe the two components in the known example. Van Maldeghem develops a geometric trace theory for perfect Ree–Tits octagons. The covering restrictions and two-root consistency are the proposed work. See https://www.math.auckland.ac.nz/~obrien/research/octagon.pdf and https://cage.ugent.be/~hvm/artikels/61.pdf .

## 2. Reconstruct the ambient geometry from overlapping thin suboctagons

Take all 24,960 copies of GO(2,1) as vertices. Pair intersection sizes with a fixed copy B occur with the following frequencies, including B itself.

| Shared points | 0 | 1 | 2 | 3 | 5 | 9 | 13 | 45 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Copies | 12,584 | 6,480 | 1,080 | 3,120 | 1,170 | 480 | 45 | 1 |

The 45 intersections of size 13 are exactly the 45 radius-two balls inside B. For each centre p in B there is a unique other suboctagon sharing that ball. Join the two copies: this gives a 45-regular graph with two 12,480-vertex components, interchanged by the full group. One component is an orbit of the derived subgroup. Its shell sizes from a vertex are 1,45,1170,9300,1964. De Bruyn records the total of 24,960 and transitivity in the full group. See https://cage.ugent.be/geometry/Files/400/Ree-Tits.pdf .

**Experiment.** Forget the labels of the 1,755 ambient points. Can the overlap data recover the labels on the edges (the centres of the shared balls) up to isomorphism, then recover collinearity? Compare automorphism groups of a single 13-overlap component, both components with the other intersection relations, and the original geometry. First find a graph-theoretic test for two edges carrying the same centre. Determine which distance data distinguish different nine-point intersection shapes. The point of the experiment is intrinsic recognition; looking up labels in the ambient graph is a control.

## 3. Find the largest radius-one packing in the dual octagon

GO(4,2) has 2,925 points, valency 12 and closed balls of size 13. A packing of disjoint balls has centres at mutual distance at least three. A perfect packing would have 225 centres. The published nonexistence for the dual Ree–Tits example is described at https://cage.ugent.be/geometry/Theses/65/PhDBishnoi.pdf . An earlier source still listed this case as open.

**Defect calculation.** Let A be collinearity adjacency, C the centres and H the uncovered points. Then 1_H=1−(I+A)1_C. Consequently 1_H is orthogonal to the −1 eigenspace. The corresponding cosine sequence, obtained from {12,8,8,8;1,1,1,3}, is (1,−1/12,−1/12,5/96,−1/64). If |C|=225−d, then |H|=13d. Let h_i be the count of holes at distance i from a test point y. Multiplication by the eigenspace projector and summing h_i gives the exact requirement

    2 h₃ + h₄ = 16(d−1) at holes, and 16d elsewhere.

For d=1 every pair of holes is at distance at most two. Any diameter-two set of 13 points here is a full ball. To see this choose holes at distance two (a clique fits on one five-point line), and let p be their middle point. For each further hole the three connecting paths of length ≤4 in the incidence graph span a tree, since their total length is ≤12 and the girth is 16. In this tree the intersection of the two radius-four incidence balls lies within incidence distance two of their midpoint p. All 13 holes are in the closed point-graph ball at p, so they fill it. Adding p would give a perfect packing. Thus the published nonexistence gives |C|≤223.

**Experiment.** Test size 223 by classifying potential 26-point hole sets satisfying these equations and then solving the exact-cover problem on their complement. Obtain a verified packing as a lower bound and a certified obstruction whenever removing a size from consideration. We have not computed the exact optimum or established priority of this upper bound.

## 4. Lift binary rank to higher powers of two

For either the point or the line opposition matrix in O(2), its integer determinant is a power of two up to sign, since the eigenvalues are signed powers of two. All Smith invariant factors are therefore 2^i. Below are their multiplicities.

| i | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Points | 26 | 272 | 52 | 324 | 406 | 272 | 78 | 246 | 52 | 26 | 1 | 0 |
| Lines | 246 | 350 | 78 | 872 | 52 | 82 | 894 | 26 | 78 | 246 | 0 | 1 |

Their determinant valuations are 7,182 and 12,135. We checked a C++ elimination and the bundled NumPy implementation of the same local Smith algorithm. Both use 16-bit modular arithmetic; all entries become pivots by valuation 11. The point binary rank 26 and the family formula 26^e for q=2^e, e odd, are published. See https://cpb-us-w2.wpmucdn.com/sites.udel.edu/dist/a/6387/files/2017/08/Ihringer_Sin_Xiang-273ucho.pdf .

**Experiment.** Determine the multiplicity of the Smith factor 2 for the point opposition matrix of O(8). Describe it in terms of the mod-four lifts of the binary kernel and compare points with lines. Work in a group module or parabolic permutation-module presentation; an explicit dense matrix at q=8 is infeasible. The binary rank formula alone supplies no formula for the next layer.

## 5. Classify maximum flag sets

The flag opposition graph on 8,775 flags has valency 4,096 and least eigenvalue −64, so the ratio bound is 135. The exact orbital multiplication table gives the six distinct eigenvalues −64,1,16,64,256,4096. Two geometric constructions attain 135. Take all flags on the 27 points of a line neighbourhood, or all flags on the 45 lines of the dual neighbourhood of a point. A direct check of all unions of suborbits of the stabilizer in T of one flag gives exactly those two extremizers centred on its line or point. This exhausts only stabilizer-invariant candidates.

**Experiment.** Test for a maximum family of 135 flags where membership depends on both its point and line. Impose the Hoffman equality for its indicator, and a constraint excluding equality with each canonical family. Alternatively induce point and line module coordinates in the least eigenspace and classify Boolean vectors there. See the flag EKR methodology at https://arxiv.org/abs/2408.05015 .

## 6. Resolve the four surviving group types at order 625

Target the array {52,42,16;1,6,28} in the repository's Cayley search. Allow arbitrary inverse-closed sets. For H=G/N abelian, projecting the group algebra sends all distance layers to weighted subsets of H. Their Fourier transforms on linear characters take values from the same integral eigenmatrix, since each layer is a polynomial in the adjacency operator. Galois invariance makes the quotient weights constant on rational atoms. Inverse Fourier transformation gives the repository's dual equalities, and the multiplicity upper bounds still hold by lifting characters of H. This argument uses normality of N only.

Every abelian quotient of order 125 of the ten nonabelian groups under consideration is among the three quotient types already rejected in search/cayley/quotient_table.csv. The character table files identify six groups whose abelianization has order 125. The remaining SmallGroup identifiers at order 625 are 7,8,9,10, each with abelianization of size 25. The six exclusions inherit the two recorded infeasibility results; we have not rerun those solvers in this round.

**Experiment.** Enumerate admissible weighted distance layers on the abelianization of each remaining group. Lift them over a central subgroup of order five, testing products of the distance layers in the group algebra and retaining all multiplicities. Require both forward and inverse products where appropriate. Output either an actual graph with its distances checked at every vertex or an exhaustive certificate of exclusion by group. The goal is the unrestricted Cayley question at this order; an exclusion would still allow a graph with no regular group. Source files and the pinned commit are at https://github.com/SCeevee-6/generalized-polygon-schemes/tree/27fdb68cea90d375044f7316d58ef6f56895526a/search/cayley .
