# Maximum non-opposite point sets in finite thick generalized octagons

Research proof for independent review. This extends the argument of SCeevee-6/generalized-polygon-schemes, commit 27fdb68, triple/max_nonopposite_proof.md. Distances below are in the point graph. The strict-stability computation in this bundle concerns only the known octagon of order (2,4).

**Claim.** In every finite thick generalized octagon of order (s,t), the largest set of pairwise non-opposite points has (s+1)(st+1) points. Every such set is the set of points on or collinear with a unique line.

### Spectrum and equality

Write k=s(t+1), K=(s+1)(st+1), v=K(1+s²t²). The point graph has intersection array {k,st,st,st;1,1,1,t+1}. Applying the distance-polynomial recurrence to the point-graph eigenvalues k, s−1+√(2st), s−1, s−1−√(2st), −t−1 gives the respective opposition eigenvalues

    s⁴t³, −s²t, s²t, −s²t, t³.

Hoffman's bound on an independent set is v/(1+s²t²)=K. For any line L, its neighbourhood N[L] has (s+1)(1+st) points and diameter at most 3. Consider a set C attaining equality. Its centred indicator lies in the sum of the two point-graph eigenspaces with eigenvalues s−1±√(2st). Thus A₄ 1_C = s²t(1−1_C). Applying (A₁−(s−1)I)²−2stI to 1_C yields the constant vector 1, since its value on the constant eigenspace is 1+s²t². Substitution of A₁² = kI+(s−1)A₁+A₂ gives the following profiles. Write a for the number of neighbours in C of a member x and m for this number at a nonmember y. Write nᵢ or mᵢ for the number of members at distance i from x or y.

    n₂=(s−1)a+s(t−s+1),     n₃=s²t+s²−sa,     n₄=0.
    m₂=(s−1)m+1,             m₃=st+s−sm,        m₄=s²t.

In particular m≤t+1. We use two elementary girth facts throughout. A non-backtracking incidence path of length ≤8 is geodesic. Between two points at point-distance ≤3 the geodesic is unique.

### Local structure

For a line M through x in C, write c_M for the number of distance-three members whose geodesic from x starts on M. Write d_M for the distance-two counterpart. Use c_y,d_y for those going through y in M other than x. If M is incomplete (has a point y outside C), then the points of C opposite y are exactly the distance-three members from x outside that branch. Consequently c_M=n₃−s²t=s(s−a).

If every line through x is full then a=k. If some line is incomplete then a≤s. If there is also a full line, a=s and that is the only full line. If all lines are incomplete then (t+1)s(s−a)=n₃, hence a=0. Thus a is 0, s or k. When there is no k-point, every line meeting C twice is full. Also, distance-two members from any x can occur behind at most one line: two in different branches would be joined by a geodesic of length four in the point graph.

**A k-point.** At such x we have n₂=s²t and n₃=0. Any distance-two member has its middle point y in C. The line xy is full and y has a neighbour in C off xy, so y is a k-point. Each such neighbour y contributes st distinct distance-two points. Hence x has s neighbours that are k-points. They belong to a single line: if two were on different lines, an off-line neighbour of one would be at distance three from the other, whose n₃ is zero. Thus all points of a line are k-points and its K-point neighbourhood equals C. Exactly its central line consists of k-points. Indeed, an off-line point has just its s neighbours on the line joining it to its projection in N[L], by the girth.

**An s-point and no k-point.** Let x be an s-point on its one full line L. Its st distance-two members must be behind one line M other than L. Otherwise a middle point on L has a neighbour off L and would be a k-point. All points of M other than x are outside C, and c_M=0. For each such y, m=1+d_y and m₂=s+st−d_y, by moving the base from x to y. The exterior profile gives d_y=t. Choose z in C collinear with y off M. It is isolated in C. Otherwise its full line would give a distance-three member from x behind M, since the line zy is incomplete.

For an isolated z and any line N through it, a point w in N other than z has m=1+d_w. Comparing its distance-three count to counts from z gives
m₃(w)=n₂(z)−d_N+c_N−c_w, hence c_w=s+s d_w−d_N. All distance-two members from z lie behind N=zy because x is one of them. In particular d_N=s(t−s+1) and d_y=t, since the t other members collinear with y lie on different lines. Therefore c_y=s². On the other hand, the s points of L other than x and the t members off M collinear with each of the s−1 remaining points of M are all at distance three from z through y. Thus c_y≥s+(s−1)t. This contradicts c_y=s² when t>s. When t≤s−2 the isolated point z already contradicts n₂(z)=s(t−s+1)<0.

**All points isolated.** The negative n₂ again excludes t≤s−2. Suppose t≥s+2. Fix x. Its s(t−s+1) distance-two members are behind one line. One point y on that line is adjacent to h≥t−s+2 members of C, with h≤t+1 by its exterior profile. These h neighbours lie on distinct lines N₁,…,N_h. For each such neighbour xᵢ, all of its distance-two members lie behind Nᵢ, because h−1≥1 of them are reached through y. Its remaining s(t−s+1)−(h−1) distance-two members project onto other points of Nᵢ and are at distance two from y. The resulting sets for different i are disjoint by uniqueness of geodesics. The exterior formula gives

    (s−1)h+1 = m₂(y) ≥ h[s(t−s+1)+1−h].

The right side less the left side is h(st−s²+2−h)−1. Since h≤t+1, it is at least h(s−1)(t−s−1)−1>0. This is impossible.

### Adjacent integer orders

Feit–Higman requires 2st to be a square, excluding s=t. For completeness the adjacent cases |s−t|=1 also fail an elementary multiplicity condition. The standard sequence of the eigenvalue −(t+1) is (−1/s)ⁱ. Its multiplicity v/Σᵢkᵢs⁻²ⁱ simplifies to

    s⁴(st+1)(s²t²+1) / [(s+t)(s²+t²)].

If |s−t|=1, then d=s²+t²=2st+1. This odd d is coprime to s and st+1. Integrality forces d to divide (st)²+1. But 4((st)²+1) is 5 modulo d. Since s,t≥2, d>5. This proves the claim for every possible thick order. Applying it to the dual also classifies maximum line families.

### Literature and scope

The known small-order result and the earlier equality proof are in the repository. The classical finite-geometry EKR literature treats closely related oppositeness problems. Priority for the precise all-order classification and sharp stability in O(2) needs specialist review. In particular, partial ovoid bounds concern pairwise opposite points. See De Beule–Mattheus–Metsch (JCTA 2022, doi:10.1016/j.jcta.2022.105657), their sequel arXiv:2408.05015, and Coolsaet–Van Maldeghem (J. Algebraic Combin. 2000, doi:10.1023/A:1026579608364).
